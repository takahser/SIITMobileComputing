//
//  Course.m
//  ScoreInput
//
//  Created by Mickael Luangkhot on 24/09/2015.
//  Copyright © 2015 ___MIKA___. All rights reserved.
//

#import "Course.h"
#import "Score.h"

@implementation Course

// Insert code here to add functionality to your managed object subclass

@end
